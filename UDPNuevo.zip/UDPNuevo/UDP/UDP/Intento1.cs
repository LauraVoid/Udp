﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


namespace UDP
{
    class Intento1
    {
        public bool enviar { get; set; }
        public UdpClient udpClient;
        public Intento1()
        {
            enviar = false;
             udpClient = new UdpClient(8080);
        }

                 
        //Se encarga de escuchar al cliente, es decir está al tanto de lo que le envian.
        public void serverThread()
        {
          
            for (; true;)
            {
                Console.WriteLine("ENVIAR DEL WHILE " + enviar);

                    IPEndPoint RemoteIpEndPoint = new IPEndPoint(IPAddress.Any, 0);
                    Console.WriteLine("VOY EN LA MITAD DEL FOR" + enviar);
                     Byte[] receiveBytes = udpClient.Receive(ref RemoteIpEndPoint);
                    
                    string returnData = Encoding.ASCII.GetString(receiveBytes);
                     Console.WriteLine(returnData);     
                
            }

         

        }

        //Se encarga de mandarle al cliente.
        public void serverThread2()
        {
            while (true)
            {
                try
                {
                    Byte[] senddata = Encoding.ASCII.GetBytes("hello world");
                    udpClient.Send(senddata, senddata.Length);
                    Console.WriteLine("Hola, por fin entre y le envie cosas al cliente.");

                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);

                }
                    
          
                
                

               
            }



        }
        public void Boolean(bool send)
        {
            enviar = send;
        }


        public byte[] ImageToArray()
        {
            Image newImage = Image.FromFile("Videos/Douglas.jpg");

            MemoryStream ms = new MemoryStream();
            newImage.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);

            return ms.ToArray();
        }


       

    }

}


  
