﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UDP
{
    public partial class Form1 : Form
    {
        private Intento1 Intento1;
        public Form1()
        {
            InitializeComponent();
            Intento1 = new Intento1();
            Thread thdUDPServer = new Thread(Intento1.serverThread);
            Thread thdUDPServer2 = new Thread(Intento1.serverThread2);
            thdUDPServer.Start();
            thdUDPServer2.Start();
            //Thread t = new Thread(SomeMethod);
            //t.Start();
            //ciclo();
        }
        
        private static void SomeMethod()
        {
            while (true)
            {
                Console.WriteLine("ENVIAR DEL WHILE ");



            }


        }
        public void ciclo()
        {
            while (true)
            {
                Console.WriteLine("Soy un ciclo");
            }
            
        }
        

        private void butCargar_Click(object sender, EventArgs e)
        {
            // Intento1.VideoToBits();
            
            Intento1.Boolean(true);
            Console.WriteLine("Enviar" + Intento1.enviar);



        }
      

    }
}
