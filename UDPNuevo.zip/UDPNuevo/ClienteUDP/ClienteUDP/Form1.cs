﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClienteUDP
{
    public partial class Form1 : Form
    {
        public UdpClient udpClient;
        public Form1()
        {
            udpClient = new UdpClient();
            udpClient.Connect("127.0.0.1", 8080);
            InitializeComponent();
            Thread thdUDPServer = new Thread(Read);
            thdUDPServer.Start();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void Send(string datos)
        {
           
            Byte[] senddata = Encoding.ASCII.GetBytes(datos);
            udpClient.Send(senddata, senddata.Length);
        }
        public void Read()
        {
            Console.WriteLine("ooooooo");
            while (true) {
                Console.WriteLine("uuuuuuu");
            IPEndPoint RemoteIpEndPoint = new IPEndPoint(IPAddress.Any, 0);
            Byte[] receiveBytes = udpClient.Receive(ref RemoteIpEndPoint);
            string returnData = Encoding.ASCII.GetString(receiveBytes);
            txtDatos.Text = returnData;

                Console.WriteLine("DATOS DEL SERVER " + returnData);

            }
        }

        public Image byteArrayToImage(byte[] byteArrayIn)
        {
            MemoryStream ms = new MemoryStream(byteArrayIn);
            Image returnImage = Image.FromStream(ms);

            txtDatos.Text = "Ya pusé la foto";

            return returnImage;
        }

        private void butRead_Click(object sender, EventArgs e)
        {

            Send("Holi soy tu cliente");
        }
    }
}
