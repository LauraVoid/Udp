﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UDP
{
    public partial class Form1 : Form
    {
        private Intento1 Intento1;
        public Form1()
        {
            Intento1 = new Intento1();
            InitializeComponent();
        }

        private void butCargar_Click(object sender, EventArgs e)
        {
           // Intento1.VideoToBits();
            axWindowsMediaPlayer1.URL =@Intento1.Path;
            axShockwaveFlash1.Movie =Intento1.Path4;


        }

        private void axShockwaveFlash1_Enter(object sender, EventArgs e)
        {

        }
    }
}
