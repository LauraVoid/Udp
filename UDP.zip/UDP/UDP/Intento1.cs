﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;


namespace UDP
{
    class Intento1
    {
        //string videoUrl = originalUrl.Replace("watch?v=", "v/");
        public string Path { get; set; }
        private string Path2;
        public string Path4 { get; set; }
        //private string Path3;


        public Intento1()
        {
            Path = "Videos/Video1.mp4";
            Path2 = "Videos/datos.txt";
           // Path3 = "Videos/datos2.txt";

            Path4 = "https://www.youtube.com/v/5BpI7V9ErFw";



        }
        public void PathOnly()
        {
            // This constructor arbitrarily assigns the local port number.
            UdpClient udpClient = new UdpClient(11000);
            try
            {
                udpClient.Connect("www.contoso.com",11000);

                // Sends a message to the host to which you have connected.
                Byte[] sendBytes = Encoding.ASCII.GetBytes("Is anybody there?");

                udpClient.Send(sendBytes, sendBytes.Length);

                // Sends a message to a different host using optional hostname and port parameters.
                UdpClient udpClientB = new UdpClient();
                udpClientB.Send(sendBytes, sendBytes.Length, "AlternateHostMachineName", 11000);

                //IPEndPoint object will allow us to read datagrams sent from any source.
                IPEndPoint RemoteIpEndPoint = new IPEndPoint(IPAddress.Any, 0);

                // Blocks until a message returns on this socket from a remote host.
                Byte[] receiveBytes = udpClient.Receive(ref RemoteIpEndPoint);
                string returnData = Encoding.ASCII.GetString(receiveBytes);

                // Uses the IPEndPoint object to determine which of these two hosts responded.
                Console.WriteLine("This is the message you received " +
                                             returnData.ToString());
                Console.WriteLine("This message was sent from " +
                                            RemoteIpEndPoint.Address.ToString() +
                                            " on their port number " +
                                            RemoteIpEndPoint.Port.ToString());

                udpClient.Close();
                udpClientB.Close();

            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }
        public void VideoToBits()
        {
            //De video a bytes
            bool read = true;
            
            byte[] datos = File.ReadAllBytes(Path);
            Stream video = File.OpenRead(Path);
            int num = 0;
                byte[] buffer = new byte[4096];

            while (read)
            {
                int bytesRead = video.Read(buffer, 0, buffer.Length);
                num += buffer.Length;
                //File.WriteAllBytes(Path3, buffer);

                if (bytesRead == 0) read=false;
               
            }

            Console.WriteLine("TAMAÑO1 "+datos.Length+ " TAMAÑO2 " +num);

            File.WriteAllBytes(Path2, datos);
            Console.WriteLine("Listin");

            // De bytes a video
            Stream stream = new MemoryStream(datos);
            Type tipo = video.GetType();

           string name= stream.GetType()+"";
            Console.WriteLine("NAME " + name);



            

        }
        



    }
}
